<!DOCTYPE html>
<html>
<head>
	<title>upload Photo profile</title>
	<script type="text/javascript" charset="utf-8" src="/ejemplos/javascript-curso/script.js"></script>

	<style type="text/css">
	img._imgProf{width: 150px;}
	</style>
</head>
<body>

<div id="onDiv">
	<input type="file" id="inputFile" accept="image/*" name="inputFile"/>
	<button id="sendPhoto">Send</button>
</div>

<div id="profilePhotoBasic">
<?php include 'connexion/url.php'; ?>
	<img id="imgProfilePhoto" class="_imgProf" src="connexion/files/<?php profPhoto(1); ?>">
</div>


<script type="text/javascript" charset="utf-8" src="script.js"></script>
</body>
</html>