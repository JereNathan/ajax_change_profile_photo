<?php
require_once 'connect.php';
	
function profPhoto($id){
	$conexion = Conexion::singleton_conexion();
	$sent = $conexion -> prepare("SELECT * FROM filephoto WHERE idprofphoto = :idprofphoto LIMIT 1");
	$sent->bindParam(":idprofphoto",$id,PDO::PARAM_STR);
	$sent -> execute();
	$res = $sent -> fetchAll();
	if(empty($res)){
		return false;
	}else{
		foreach($res as $span){
			if($span['photo'] == null){
				echo 'void.png';
			}else{
				echo $span['photo'];
			}
		}
	}
}
?>
