<?php
require_once 'connect.php';

$valueOne = $_FILES['inputFile']['name'];
$tipo = $_FILES['inputFile']['type'];
$tamano = $_FILES['inputFile']['size'];
 

if(($valueOne == !NULL) && ($_FILES['inputFile']['size'] <= 20000000)){
   if (($_FILES["inputFile"]["type"] == "image/gif")
   || ($_FILES["inputFile"]["type"] == "image/jpeg")
   || ($_FILES["inputFile"]["type"] == "image/jpg")
   || ($_FILES["inputFile"]["type"] == "image/png"))
   {
    $directorio = 'files/';
    $changeDirName = sha1(SALT.$valueOne.PEPPER);
    $one = 1;
    move_uploaded_file($_FILES['inputFile']['tmp_name'],$directorio.$changeDirName);
    $conexion = Conexion::singleton_conexion();
	$q = $conexion -> prepare("UPDATE filephoto SET photo = :photo WHERE idprofphoto = :idprofphoto");
	$q->bindParam(":photo",$changeDirName,PDO::PARAM_STR);
	$q->bindParam(":idprofphoto",$one,PDO::PARAM_STR);


	if($q->execute()){
		echo 'connexion/files/'.$changeDirName;
	}

    }else{
       echo "No se puede subir una imagen con ese formato ";
    }
}else{
   if($valueOne == !NULL) echo "La imagen es demasiado grande "; 
}