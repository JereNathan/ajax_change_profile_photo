var onDivForm = $d.querySelector("#onDiv");
var imgDivPhoto = $d.querySelector("#imgProfilePhoto");
var imageDiv = $d.querySelector("#inputFile");
var buttonSend = $d.querySelector("#sendPhoto");


$.addevent(imageDiv,"change",function(event){
    var input = event.target;

    var reader = new FileReader();
    reader.onload = function(){
      var dataURL = reader.result;
      imgDivPhoto.src = dataURL;

        $.addevent(buttonSend,"click",function(event){
          var onForm = new FormData();
          onForm.append("inputFile",imageDiv.files[0],dataURL);
            
            $.ajaxopen("POST","connexion/send.php",true);
              connexion.onload = function(){
                if($.prot()){
                  var answer = connexion.responseText;
                  imgDivPhoto.src = answer;
                }else{
                  return false;
                }
              };
          
            $.ajaxsend(onForm);
            event.preventDefault();
            }); 

    };
    reader.readAsDataURL(input.files[0]);
});

